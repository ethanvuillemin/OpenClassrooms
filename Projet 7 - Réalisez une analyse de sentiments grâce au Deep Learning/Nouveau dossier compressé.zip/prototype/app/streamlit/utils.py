import requests

def get_data():
    return {"data": "some_data"}