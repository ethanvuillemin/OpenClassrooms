import mlflow
from mlflow.models.signature import infer_signature
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def log_model_with_mlflow(
    model,
    X_train,
    y_train,
    X_test,
    y_test,
    tags,
    model_name,
    model_version=None,
    experiment_name="Modèle sur mesure avancé",
    hyperparams=None,
):
    """
    Enregistre un modèle TensorFlow avec MLflow, incluant les métriques, les hyperparamètres,
    les tags et le modèle.

    Cette fonction configure une expérience MLflow, démarre une nouvelle exécution, évalue
    les performances du modèle sur des données de test, enregistre les métriques clés
    (accuracy, precision, recall, F1, ROC AUC, PR AUC), les hyperparamètres, les tags
    ainsi que le modèle au format MLflow.

    Args:
        model (tf.keras.Model): Modèle TensorFlow à logger.
        X_train (array-like or pd.DataFrame): Données d'entraînement utilisées pour inférer la signature du modèle.
        y_train (array-like or pd.Series): Labels d'entraînement (utilisés uniquement pour l'évaluation si nécessaire).
        X_test (array-like or pd.DataFrame): Données de test pour l'évaluation du modèle.
        y_test (array-like or pd.Series): Labels de test pour l'évaluation du modèle.
        tags (dict): Dictionnaire de tags supplémentaires à associer à l'exécution MLflow.
        model_name (str): Nom du modèle à utiliser comme nom de l'exécution MLflow.
        model_version (str, optional): Version du modèle à enregistrer comme tag. Par défaut None.
        experiment_name (str, optional): Nom de l'expérience MLflow. Par défaut "Modèle sur mesure avancé".
        hyperparams (dict, optional): Hyperparamètres du modèle à logger. Si None, tente de les extraire automatiquement.
            Si cela échoue, un message est affiché mais l'exécution continue. Par défaut None.

    Returns:
        None: Les résultats sont directement enregistrés dans MLflow.
    """

    mlflow.set_experiment(experiment_name)

    with mlflow.start_run(run_name=model_name):
        # Récupération des hyperparamètres
        if hyperparams is None:
            hyperparams = {}
            try:
                config = model.get_config()
                hyperparams["layers"] = str(config.get("layers", "N/A"))
                hyperparams["optimizer"] = str(model.optimizer.get_config())
            except Exception as e:
                print(
                    f"Impossible de récupérer les hyperparamètres automatiquement : {e}"
                )

        for key, value in hyperparams.items():
            mlflow.log_param(key, value)

        # Prédiction des classes et des probabilités
        y_pred_proba = model.predict(X_test).ravel()
        y_pred_class = (y_pred_proba > 0.5).astype("int32")

        # Calcul des métriques
        accuracy = accuracy_score(y_test, y_pred_class)
        precision = precision_score(y_test, y_pred_class)
        recall = recall_score(y_test, y_pred_class)
        f1 = f1_score(y_test, y_pred_class)
        roc_auc = roc_auc_score(y_test, y_pred_proba)
        pr_auc = average_precision_score(y_test, y_pred_proba)

        # Log des métriques dans MLflow
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1", f1)
        mlflow.log_metric("roc_auc", roc_auc)
        mlflow.log_metric("pr_auc", pr_auc)

        # Informations sur le modèle (nom et version)
        mlflow.set_tag("mlflow.note.content", model_name)
        if model_version:
            mlflow.set_tag("model_version", model_version)

        # Logger le modèle
        signature = infer_signature(X_train[:2], model.predict(X_train[:2]))
        input_ex = X_train[:2]
        mlflow.tensorflow.log_model(
            model, "model", signature=signature, input_example=input_ex
        )

        # Ajouter les tags supplémentaires
        for key, val in tags.items():
            mlflow.set_tag(key, val)
